# Dialogue-System
Research Project of Dialogue Systems and how to implement them in your games. 

# About me
My name is Sara and I'm a second year student of Video Game Design and Development at the CITM, UPC. 
